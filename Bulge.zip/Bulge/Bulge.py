# -*- coding: mbcs -*-
from part import *
from material import *
from section import *
from assembly import *
from step import *
from interaction import *
from load import *
from mesh import *
from optimization import *
from job import *
from sketch import *
from visualization import *
from connectorBehavior import *
session.journalOptions.setValues(replayGeometry=COORDINATE, recoverGeometry=COORDINATE)




# ============================== Sheet/Blank Part ==============================
mdb.models['Model-1'].ConstrainedSketch(name='__profile__', sheetSize=400.0)
mdb.models['Model-1'].sketches.changeKey(fromName='__profile__', toName=
	'__save__')
mdb.models['Model-1'].ConstrainedSketch(name='__profile__', sheetSize=200.0)
mdb.models['Model-1'].sketches['__profile__'].ConstructionLine(point1=(0.0, 
	-100.0), point2=(0.0, 100.0))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].FixedConstraint(entity=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0), 
	))
mdb.models['Model-1'].sketches['__profile__'].rectangle(point1=(0.0, 0.0), 
	point2=(SheetRadius, SheetThickness))
mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Sheet', type=
	DEFORMABLE_BODY)

mdb.models['Model-1'].sketches['__profile__'].FixedConstraint(entity=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 0.0), ))

mdb.models['Model-1'].sketches['__profile__'].ObliqueDimension(textPoint=(
	-3, 3), value=SheetThickness, vertex1=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 0.0), ), 
	vertex2=mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 
	SheetThickness), ))
mdb.models['Model-1'].sketches['__profile__'].HorizontalDimension(textPoint=(
	60, -4), value=SheetRadius, vertex1=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 0.0), ), 
	vertex2=mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((SheetRadius, 
	0.0), ))
mdb.models['Model-1'].parts['Sheet'].BaseSolidRevolve(angle=90.0, 
	flipRevolveDirection=OFF, sketch=
	mdb.models['Model-1'].sketches['__profile__'])
del mdb.models['Model-1'].sketches['__profile__']

# Create Bottom and Top Surfaces
mdb.models['Model-1'].parts['Sheet'].Surface(name='Sheet_BottomSurf', 
	side1Faces=mdb.models['Model-1'].parts['Sheet'].faces.findAt(((0.1, 
	0.0, 0.1), )))

mdb.models['Model-1'].parts['Sheet'].Surface(name='Sheet_TopSurf', 
	side1Faces=mdb.models['Model-1'].parts['Sheet'].faces.findAt(((0.1, 
	SheetThickness, 0.1), )))

# Create Edge and Whole Sets
mdb.models['Model-1'].parts['Sheet'].Set(faces=
	mdb.models['Model-1'].parts['Sheet'].faces.findAt(((2.852757, 0.5, 
	59.932143), )), name='Sheet_Edge')
mdb.models['Model-1'].parts['Sheet'].Set(cells=
	mdb.models['Model-1'].parts['Sheet'].cells.findAt(((6.18034, 0.0, 
	58.802007), )), name='Sheet_Whole')

mdb.models['Model-1'].parts['Sheet'].regenerate()



# ============================== Die Part ==============================
# Die and its angle for EHFF/Bulge
mdb.models['Model-1'].ConstrainedSketch(name='__profile__', sheetSize=200.0)
mdb.models['Model-1'].sketches['__profile__'].ConstructionLine(point1=(0.0, 
	-100.0), point2=(0.0, 100.0))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].FixedConstraint(entity=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0), 
	))
mdb.models['Model-1'].sketches['__profile__'].Line(point1=(0.0, -50.0), point2=
	(60.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].Line(point1=(60.0, 0.0), point2=(
	70.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((65.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].HorizontalConstraint(
	addUndoState=False, entity=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((65.0, 0.0), 
	))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((30.0, -25.0))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((65.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].FilletByRadius(curve1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((30.0, 
	-25.0), ), curve2=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((65.0, 0.0), 
	), nearPoint1=(58.5615653991699, -0.679225921630859), nearPoint2=(
	62.1581153869629, 0.465686798095703), radius=10.0)
mdb.models['Model-1'].sketches['__profile__'].Spot(point=(0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].FixedConstraint(entity=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 0.0), 
	))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((63.620499, 0.0))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].HorizontalDimension(textPoint=(
	6.18575477600098, 11.1392707824707), value=60.0, vertex1=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((
	63.6204985944282, 1.26217744835362e-29), ), vertex2=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 0.0), 
	))
mdb.models['Model-1'].sketches['__profile__'].dimensions[0].setValues(
	textPoint=(60.0, -10.0))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((70.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].HorizontalDimension(textPoint=(
	8.12355422973633, 15.0153465270996), value=70.0, vertex1=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((70.0, 0.0), 
	), vertex2=mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((
	0.0, 0.0), ))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((70.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].FixedConstraint(entity=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((70.0, 0.0), 
	))
mdb.models['Model-1'].sketches['__profile__'].CircleByCenterPerimeter(center=(
	0.0, -43.75), point1=(1.57209789786138, -45.6728362564254))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((1.572098, 
	-45.672836))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((24.988829, 
	-26.158893))
mdb.models['Model-1'].sketches['__profile__'].CoincidentConstraint(
	addUndoState=False, entity1=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((
	1.57209789786138, -45.6728362564254), ), entity2=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((24.988829, 
	-26.158893), ))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, -43.75))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].CoincidentConstraint(
	addUndoState=False, entity1=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((0.0, 
	-43.75), ), entity2=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0), 
	))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((-1.572098, 
	-41.827164))
mdb.models['Model-1'].sketches['__profile__'].autoTrimCurve(curve1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((-1.572098, 
	-41.827164), ), point1=(2.42621970176697, -43.3794860839844))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((-2.339289, 
	-44.584576))
mdb.models['Model-1'].sketches['__profile__'].autoTrimCurve(curve1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((-2.339289, 
	-44.584576), ), point1=(-0.319907903671265, -46.1992797851563))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((24.988829, 
	-26.158893))
mdb.models['Model-1'].sketches['__profile__'].autoTrimCurve(curve1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((24.988829, 
	-26.158893), ), point1=(0.166663408279419, -46.8592338562012))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((-1.810249, 
	-48.491459))
mdb.models['Model-1'].sketches['__profile__'].autoTrimCurve(curve1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((-1.810249, 
	-48.491459), ), point1=(-0.2599196434021, -47.2125396728516))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((1.606048, 
	-45.644571))
mdb.models['Model-1'].sketches['__profile__'].autoTrimCurve(curve1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((1.606048, 
	-45.644571), ), point1=(1.58638453483582, -45.6526565551758))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((27.585128, 
	-23.995311))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.834576, 
	-46.089289))
mdb.models['Model-1'].sketches['__profile__'].TangentConstraint(entity1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((27.585128, 
	-23.995311), ), entity2=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.834576, 
	-46.089289), ))
# New after 2016
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.845426, 
	-46.085328))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].PerpendicularConstraint(entity1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.845426, 
	-46.085328), ), entity2=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((0.0, 0.0), 
	))

mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((56.595748, 
	-0.597284))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((27.585128, 
	-23.995311))
mdb.models['Model-1'].sketches['__profile__'].TangentConstraint(entity1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((56.595748, 
	-0.597284), ), entity2=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((27.585128, 
	-23.995311), ))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((27.585128, 
	-23.995311))
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((65.0, 0.0))
mdb.models['Model-1'].sketches['__profile__'].AngularDimension(line1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((27.585128, 
	-23.995311), ), line2=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((65.0, 0.0), 
	), textPoint=(43.1456909179688, -5.37823677062988), value=34.0)


mdb.models['Model-1'].sketches['__profile__'].dimensions[3].setValues(value=90)
# New 2016
mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((35.356549, 
	-70.766571))
mdb.models['Model-1'].sketches['__profile__'].autoTrimCurve(curve1=
	mdb.models['Model-1'].sketches['__profile__'].geometry.findAt((35.356549, 
	-70.766571), ), point1=(49.9813194274902, -35.5557556152344))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((50.0, 
	-9.999999))
mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((50.0, 
	-35.412442))
mdb.models['Model-1'].sketches['__profile__'].VerticalDimension(textPoint=(
	55.1138801574707, -31.1821823120117), value=60.0, vertex1=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((50.0, 
	-9.99999908598159), ), vertex2=
	mdb.models['Model-1'].sketches['__profile__'].vertices.findAt((50.0, 
	-35.4124420809855), ))

mdb.models['Model-1'].Part(dimensionality=THREE_D, name='Die', type=
	DISCRETE_RIGID_SURFACE)
mdb.models['Model-1'].parts['Die'].BaseShellRevolve(angle=90.0, 
	flipRevolveDirection=OFF, sketch=
	mdb.models['Model-1'].sketches['__profile__'])
del mdb.models['Model-1'].sketches['__profile__']


# Adding the RP
mdb.models['Model-1'].parts['Die'].ReferencePoint(point=(0.0, 0.0, 0.0))
mdb.models['Model-1'].parts['Die'].features.changeKey(fromName='RP', toName=
	'Die_RP')

# Create Die Top Surface 
mdb.models['Model-1'].parts['Die'].Surface(name='Die_TopSurf', side1Faces=
	mdb.models['Model-1'].parts['Die'].faces.findAt(((1.63537, -26.666666, 
	49.973249), ), ((6.607562, -0.209159, 57.587607), ), ((1.141776, 0.0, 
	63.300715), ), ))


# ============================== Sheet and Die for Bulge ==============================
#Enlarge die hole
mdb.models['Model-1'].ConstrainedSketch(name='__edit__', objectToCopy=
	mdb.models['Model-1'].parts['Die'].features['Shell revolve-1'].sketch)
mdb.models['Model-1'].parts['Die'].projectReferencesOntoSketch(filter=
	COPLANAR_EDGES, sketch=mdb.models['Model-1'].sketches['__edit__'], 
	upToFeature=mdb.models['Model-1'].parts['Die'].features['Shell revolve-1'])
mdb.models['Model-1'].sketches['__edit__'].delete(objectList=(
	mdb.models['Model-1'].sketches['__edit__'].constraints[18], ))
mdb.models['Model-1'].sketches['__edit__'].dimensions[1].setValues(value=SheetRadius)
mdb.models['Model-1'].sketches['__edit__'].dimensions[2].setValues(value=SheetRadius+10)
mdb.models['Model-1'].sketches['__edit__'].vertices.findAt((SheetRadius+10, 0.0))
mdb.models['Model-1'].sketches['__edit__'].FixedConstraint(entity=
	mdb.models['Model-1'].sketches['__edit__'].vertices.findAt((SheetRadius+10, 0.0), ))
mdb.models['Model-1'].sketches['__edit__'].dimensions[0].setValues(value=5)
mdb.models['Model-1'].sketches['__edit__'].geometry.findAt((75.000001, 
	-29.999999))
mdb.models['Model-1'].sketches['__edit__'].autoTrimCurve(curve1=
	mdb.models['Model-1'].sketches['__edit__'].geometry.findAt((75.000001, 
	-29.999999), ), point1=(75.257568359375, -31.3715972900391))
mdb.models['Model-1'].parts['Die'].features['Shell revolve-1'].setValues(
	sketch=mdb.models['Model-1'].sketches['__edit__'])
del mdb.models['Model-1'].sketches['__edit__']
mdb.models['Model-1'].parts['Die'].deleteFeatures(('Datum plane-1', 
'Datum plane-2', 'Partition face-1', 'Partition face-2'))
mdb.models['Model-1'].parts['Die'].regenerate()


# ============================== Hardening Properties ==============================
Hard_Method='ABAQUS_JC'
mdb.models['Model-1'].Material(name=(Hard_Method))
mdb.models['Model-1'].materials[(Hard_Method)].Density(table=((Density, ), ))
mdb.models['Model-1'].materials[(Hard_Method)].Elastic(table=((E, 
	xnu), ))
mdb.models['Model-1'].materials[(Hard_Method)].Plastic(hardening=JOHNSON_COOK,
	table=((A, B, n, 0, 0, 0), ))
if C > 0:
	mdb.models['Model-1'].materials[(Hard_Method)].plastic.RateDependent(
		table=((C, EpsilonRef), ), type=JOHNSON_COOK)


#%-------------- Step and Time Point -----------------------------------
mdb.models['Model-1'].ExplicitDynamicsStep(name='Step-1', previous='Initial')
mdb.models['Model-1'].fieldOutputRequests['F-Output-1'].setValues(numIntervals=
	100, variables=('S', 'TRIAX', 'MISES', 'PE', 'PEEQ', 'LE', 'V', 'U','STATUS',
		'ER','ERV','SDV','CSTRESS'))
mdb.models['Model-1'].steps['Step-1'].setValues(timePeriod=total_time)

mdb.models['Model-1'].fieldOutputRequests['F-Output-1'].setValues(numIntervals=
    50)


if Mass_Scaling > 0: #Add mass scaling for Bulge test
	mdb.models['Model-1'].steps['Step-1'].setValues(massScaling=((SEMI_AUTOMATIC, 
		MODEL, AT_BEGINNING, Mass_Scaling, 0.0, None, 0, 0, 0.0, 0.0, 0, None), ))


#%-------------- Create Friction properties -----------------------------------------------------
# Create a Default contact
mdb.models['Model-1'].ContactProperty('DefaultContact')

# Create Friction contact for Sheet-Die
mdb.models['Model-1'].ContactProperty('Friction_DieSheet')
mdb.models['Model-1'].interactionProperties['Friction_DieSheet'].TangentialBehavior(
	elasticSlipStiffness=None, exponentialDecayDefinition=COEFFICIENTS, 
	formulation=EXPONENTIAL_DECAY, fraction=0.005, maximumElasticSlip=FRACTION, 
	table=((StaticF_coeff, DynamicF_coeff, 1.0), ))



#%-------------- Assembly -----------------------------------
mdb.models['Model-1'].rootAssembly.DatumCsysByDefault(CARTESIAN)
mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Die-1', part=
    mdb.models['Model-1'].parts['Die'])
mdb.models['Model-1'].rootAssembly.Instance(dependent=ON, name='Sheet-1', part=
    mdb.models['Model-1'].parts['Sheet'])
mdb.models['Model-1'].rootAssembly.regenerate()



#%-------------- Assigning material -----------------------------------
# For Sheet
mdb.models['Model-1'].parts['Sheet'].regenerate()
#--- Create Sheet Section
mdb.models['Model-1'].HomogeneousSolidSection(material=(Hard_Method), name=
    'Sheet_Section', thickness=None)
#--- Assign Material to section
mdb.models['Model-1'].parts['Sheet'].SectionAssignment(offset=0.0, offsetField=
    '', offsetType=MIDDLE_SURFACE, region=
    mdb.models['Model-1'].parts['Sheet'].sets['Sheet_Whole'], sectionName=
    'Sheet_Section', thicknessAssignment=FROM_SECTION)



# =========================== Mesh individual parts =========================== 
# Meshing the Sheet for Bulge:
mdb.models['Model-1'].parts['Sheet'].seedEdgeBySize(constraint=FINER, 
    deviationFactor=0.1, edges=
    mdb.models['Model-1'].parts['Sheet'].edges.findAt(((80, 1.125, 0.0), )), 
    minSizeFactor=0.1, size=SheetThickness/SheetThickDivide)
mdb.models['Model-1'].parts['Sheet'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=Sheet_MeshSize)

mdb.models['Model-1'].parts['Sheet'].setElementType(elemTypes=(ElemType(
    elemCode=C3D8R, elemLibrary=EXPLICIT, secondOrderAccuracy=OFF, 
    kinematicSplit=AVERAGE_STRAIN, hourglassControl=ENHANCED, 
    distortionControl=DEFAULT), ElemType(elemCode=C3D6, elemLibrary=EXPLICIT), 
    ElemType(elemCode=C3D4, elemLibrary=EXPLICIT)), regions=(
    mdb.models['Model-1'].parts['Sheet'].cells.findAt(((0.5, 0.5, 
    46.429166), )), ))

mdb.models['Model-1'].parts['Sheet'].generateMesh()

# Meshing the Die
mdb.models['Model-1'].parts['Die'].seedPart(deviationFactor=0.01, minSizeFactor=
    0.1, size=Die_MeshSize) 
mdb.models['Model-1'].rootAssembly.regenerate()
mdb.models['Model-1'].parts['Die'].generateMesh()


#%-------------- Applying BC and Load ----------------------------------------------
mdb.models['Model-1'].SmoothStepAmplitude(data=Pulse_History, name='Pulse_History', timeSpan=STEP) #TOTAL

# Simple Load Applying to sheet; Magnitude of pressure
mdb.models['Model-1'].Pressure(amplitude='Pulse_History', createStepName=
    'Step-1', distributionType=UNIFORM, field='', magnitude=Max_pressure, name=
    'Pressure_on_Sheet', region=
    mdb.models['Model-1'].rootAssembly.instances['Sheet-1'].surfaces['Sheet_TopSurf'])

# Die fixed BC
mdb.models['Model-1'].rootAssembly.Set(name='Die_RP', referencePoints=(
    mdb.models['Model-1'].rootAssembly.instances['Die-1'].referencePoints[2], 
    ))
mdb.models['Model-1'].EncastreBC(createStepName='Initial', localCsys=None, 
    name='Die_Fixed', region=mdb.models['Model-1'].rootAssembly.sets['Die_RP'])

# Sheet BC
mdb.models['Model-1'].rootAssembly.Set(faces=
    mdb.models['Model-1'].rootAssembly.instances['Sheet-1'].faces.findAt(((
    3.803676, SheetThickness/2, 79.909524), )), name='sheet_edge_surf')
mdb.models['Model-1'].EncastreBC(createStepName='Initial', localCsys=None, 
    name='SheetEdge_BC', region=
    mdb.models['Model-1'].rootAssembly.sets['sheet_edge_surf'])
mdb.models['Model-1'].rootAssembly.Set(faces=
    mdb.models['Model-1'].rootAssembly.instances['Sheet-1'].faces.findAt(((
    46.666667, 0.5, 0.0), )), name='XY_SymEdge')
mdb.models['Model-1'].ZsymmBC(createStepName='Initial', localCsys=None, name=
    'Sheet_XY_Sym', region=mdb.models['Model-1'].rootAssembly.sets['XY_SymEdge'])
mdb.models['Model-1'].rootAssembly.Set(faces=
    mdb.models['Model-1'].rootAssembly.instances['Sheet-1'].faces.findAt(((0.0, 
    1.0, 46.666667), )), name='YZ_SymEdge')
mdb.models['Model-1'].XsymmBC(createStepName='Initial', localCsys=None, name=
    'Sheet_YZ_Sym', region=mdb.models['Model-1'].rootAssembly.sets['YZ_SymEdge'])



# Create the Job
mdb.Job(activateLoadBalancing=False, atTime=None, contactPrint=OFF, 
	description='', echoPrint=OFF, explicitPrecision=DOUBLE, historyPrint=OFF, 
	memory=90, memoryUnits=PERCENTAGE, model='Model-1', modelPrint=OFF, 
	multiprocessingMode=DEFAULT, name='Job-1', nodalOutputPrecision=FULL, 
	numCpus=numCPU, numDomains=numCPU, parallelizationMethodExplicit=DOMAIN, queue=None, 
	scratch='', type=ANALYSIS, waitHours=0, waitMinutes=0)


#%-------------- Save .cae file -----------------------------------
#mdb.saveAs(pathName='C:\temp\Bulge')

#mdb.jobs[Test_name].submit(consistencyChecking=OFF)









# =========================== Duplicating/Modifying ===========================

# ------ Case 1: Different Mesh Sizes ------------------------------
mdb.models.changeKey(fromName='Model-1', toName='Base-Model')
# Copy Mesh-1 to Mesh-2
mdb.Model(name='Mesh-2', objectToCopy=mdb.models['Base-Model'])
# Changing Mesh Size
mdb.models['Mesh-2'].parts['Sheet'].deleteMesh()
mdb.models['Mesh-2'].parts['Sheet'].deleteSeeds()
mdb.models['Mesh-2'].parts['Sheet'].seedPart(deviationFactor=0.1, 
    minSizeFactor=0.1, size=2)
mdb.models['Mesh-2'].parts['Sheet'].generateMesh()
mdb.models['Mesh-2'].rootAssembly.regenerate()
# Create a new job-2
mdb.Job(activateLoadBalancing=False, atTime=None, contactPrint=OFF, 
	description='', echoPrint=OFF, explicitPrecision=DOUBLE, historyPrint=OFF, 
	memory=90, memoryUnits=PERCENTAGE, model='Mesh-2', modelPrint=OFF, 
	multiprocessingMode=DEFAULT, name='Mesh-2', nodalOutputPrecision=FULL, 
	numCpus=numCPU, numDomains=numCPU, parallelizationMethodExplicit=DOMAIN, queue=None, 
	scratch='', type=ANALYSIS, waitHours=0, waitMinutes=0)




# ------ Case 2: Diff Max Pressure ------------------------------
mdb.Model(name='MaxP-2', objectToCopy=mdb.models['Base-Model'])
mdb.models['MaxP-2'].loads['Pressure_on_Sheet'].setValues(magnitude=10.0)
mdb.models['MaxP-2'].rootAssembly.regenerate()
# Create a new job-2
mdb.Job(activateLoadBalancing=False, atTime=None, contactPrint=OFF, 
	description='', echoPrint=OFF, explicitPrecision=DOUBLE, historyPrint=OFF, 
	memory=90, memoryUnits=PERCENTAGE, model='MaxP-2', modelPrint=OFF, 
	multiprocessingMode=DEFAULT, name='MaxP-2', nodalOutputPrecision=FULL, 
	numCpus=numCPU, numDomains=numCPU, parallelizationMethodExplicit=DOMAIN, queue=None, 
	scratch='', type=ANALYSIS, waitHours=0, waitMinutes=0)







# =========================== Modifying in a loop ===========================

Names 		= ['Mesh-3','Mesh-4','Mesh-5']
MeshSizes 	= [3,4,5]
i 			= 0
for iName in Names:
	mdb.Model(name=iName, objectToCopy=mdb.models['Base-Model'])
	# Changing Mesh Size
	mdb.models[iName].parts['Sheet'].deleteMesh()
	mdb.models[iName].parts['Sheet'].deleteSeeds()
	mdb.models[iName].parts['Sheet'].seedPart(deviationFactor=0.1, 
    	minSizeFactor=0.1, size=MeshSizes[i])
	mdb.models[iName].parts['Sheet'].generateMesh()
	mdb.models[iName].rootAssembly.regenerate()
	# Create a new job-2
	mdb.Job(activateLoadBalancing=False, atTime=None, contactPrint=OFF, 
		description='', echoPrint=OFF, explicitPrecision=DOUBLE, historyPrint=OFF, 
		memory=90, memoryUnits=PERCENTAGE, model=iName, modelPrint=OFF, 
		multiprocessingMode=DEFAULT, name=iName, nodalOutputPrecision=FULL, 
		numCpus=numCPU, numDomains=numCPU, parallelizationMethodExplicit=DOMAIN, queue=None, 
		scratch='', type=ANALYSIS, waitHours=0, waitMinutes=0)
	i=i+1










